import React, { useState, useEffect } from 'react';
import { fetchProviders } from '../services/api';
import Sidebar from '../components/Sidebar';
import styled from 'styled-components';

const CenteredButton = styled.button`
  background-color: #049dd2; 
  color: white;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 0.8rem;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  border-radius: 10px;
  z-index: 4; 
`;

interface PageContainerProps {
  showProviders: boolean;
}

const PageContainer = styled.div<PageContainerProps>`
  background-color: ${({ showProviders }) => showProviders ? '#131924' : '#3f607a'}; 
  min-height: 100vh;
  position: relative;
  padding: 20px;
  transition: background-color 0.2s;
  filter: ${({ showProviders }) => (showProviders ? 'blur(0.7px)' : 'none')}; 
  z-index: 1; 
`;

const ProvidersContainer = styled.div<PageContainerProps>`
  display: flex;
  flex-direction: column;
  width: 300px; 
  transition: transform 0.3s ease-in-out;
  transform: ${({ showProviders }) => (showProviders ? 'translateX(0)' : 'translateX(100%)')};
  position: fixed;
  top: 0;
  right: 0;
  background-color: #377A92; 
  min-height: 100vh;
  padding: 20px;
  box-sizing: border-box; 
  z-index: 2; 
`;

const ProvidersList: React.FC = () => {
  const [providers, setProviders] = useState<string[]>([]);
  const [showProviders, setShowProviders] = useState(false);

  useEffect(() => {
    const loadProviders = async () => {
      try {
        const providerList = await fetchProviders();
        setProviders(providerList);
      } catch {

      }
    };

    loadProviders();
  }, []);

  return (
    <>
      <PageContainer showProviders={showProviders}>
        <CenteredButton onClick={() => setShowProviders(!showProviders)}>
          Explore Web APIs
        </CenteredButton>
      </PageContainer>
      <ProvidersContainer showProviders={showProviders}>
        <Sidebar 
          providers={providers} 
          onSelect={(provider: string) => console.log(provider)} 
          onClose={() => setShowProviders(false)} 
          showProviders={showProviders}
        />
      </ProvidersContainer>
    </>
  );
};

export default ProvidersList;
