import axios, { AxiosResponse } from 'axios';

interface ContactDetails {
  email?: string;
  url?: string;
}

interface LogoInfo {
  url?: string;
}

interface ProviderInfo {
  title: string;
  description: string;
  contact: ContactDetails;
  swaggerUrl?: string;
  xLogo?: LogoInfo; // Add xLogo property here
}

interface ApiDetails {
  info: ProviderInfo;
  swaggerUrl?: string;
  logoUrl?: string; 
}

interface ProvidersResponse {
  data: string[];
}

interface FetchProviderDetailsResponse {
  apis: {
    [key: string]: ApiDetails;
  };
}

const BASE_URL = 'https://api.apis.guru/v2';

// Handle API request errors
const handleApiError = (error?: any): void => {
  console.error('API request error', error);
};

// Function to fetch the list of providers
export const fetchProviders = async (): Promise<string[]> => {
  try {
    const { data }: AxiosResponse<ProvidersResponse> = await axios.get(`${BASE_URL}/providers.json`);
    return data.data;
  } catch {
    handleApiError();
    return [];
  }
};

export const fetchProviderDetails = async (provider: string): Promise<ApiDetails | null> => {
  try {
    const { data }: AxiosResponse<FetchProviderDetailsResponse> = await axios.get(`${BASE_URL}/${provider}.json`);
    
    const apiKey = Object.keys(data.apis)[0];
    if (!apiKey) {
      throw new Error('No API details found for the provider.');
    }

    const apiDetails = data.apis[apiKey];

    // Construct logo URL if available
    const logoUrl = apiDetails.info.xLogo?.url ? `https://api.apis.guru/v2/cache/logo/${apiDetails.info.xLogo.url}` : '';

    return {
      ...apiDetails,
      logoUrl, // Update logoUrl with the constructed URL
    };
  } catch (error) {
    handleApiError(error);
    return null;
  }
};
