import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ProvidersList from './screens/ProvidersList';
import APIDetails from './screens/APIDetails';

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<ProvidersList />} />
      <Route path="/api-details/:provider" element={<APIDetails />} />
    </Routes>
  </BrowserRouter>
);

export default App;
