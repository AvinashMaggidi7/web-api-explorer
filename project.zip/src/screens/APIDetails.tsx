import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchProviderDetails } from '../services/api';

interface ContactDetails {
  email?: string;
  url?: string;
  name?: string;
}

interface ProviderInfo {
  title: string;
  description: string;
  contact: ContactDetails;
  swaggerUrl?: string;
}

interface ApiDetails {
  info: ProviderInfo;
  swaggerUrl?: string;
  logoUrl?: string;
}

const APIDetails: React.FC = () => {
  const { provider } = useParams<{ provider?: string }>();
  const [apiDetails, setApiDetails] = useState<ApiDetails | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [logoError, setLogoError] = useState<string | null>(null);
  const [logoLoading, setLogoLoading] = useState<boolean>(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchApiDetails = async () => {
      if (provider) {
        try {
          const details = await fetchProviderDetails(provider);
          if (details && details.info && typeof details.info.title === 'string' && typeof details.info.description === 'string') {
            setApiDetails(details);
            setError(null);
          } else {
            setError('Details not found.');
          }
        } catch (err) {
          setError('Error fetching details.');
        }
      } else {
        setError('Provider not specified.');
      }
    };

    fetchApiDetails();
  }, [provider]);

  const handleImageLoad = () => {
    setLogoLoading(false);
    setLogoError(null);
  };

  const handleImageError = () => {
    setLogoLoading(false);
    setLogoError('Logo image could not be loaded.');
  };

  const logoUrl = apiDetails?.logoUrl
    ? `https://api.apis.guru/v2/cache/logo/${apiDetails.logoUrl}`
    : '';

  return (
    <div style={{ backgroundColor: '#3f607a', minHeight: '100vh', padding: '20px', color: 'white' }}>
      <div style={{ maxWidth: '800px', margin: '30px auto', padding: '20px', backgroundColor: '#3f607a', borderRadius: '8px', boxShadow: '0 0 10px rgba(0,0,0,0.1)' }}>
       
        {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
        {apiDetails ? (
          <div>
            <h1 style={{ marginTop: '0', textAlign:'center' }}>{apiDetails.info.title}</h1>
            
            {apiDetails.logoUrl ? (
              <div style={{ textAlign: 'center', marginBottom: '20px' }}>
                {logoLoading && <p>Loading logo...</p>}
                <img 
                  src={logoUrl} 
                  alt={`${apiDetails.info.title} logo`} 
                  style={{ maxWidth: '200px', height: 'auto', display: logoLoading ? 'none' : 'block' }} 
                  onLoad={handleImageLoad}
                  onError={handleImageError}
                />
                {logoError && (
                  <p style={{ color: 'red' }}>{logoError}</p>
                )}
              </div>
            ) : (
              <p style={{ textAlign: 'center', color: '#999' }}>Logo not available</p>
            )}

            <p><strong>Description:</strong> {apiDetails.info.description}</p>
            
            <div style={{ marginBottom: '20px' }}>
              {apiDetails.swaggerUrl && (
                <div>
                  <h3>Swagger</h3>
                  <p><a href={apiDetails.swaggerUrl} target="_blank" rel="noopener noreferrer" style={{ color: 'white' }}>View Swagger Documentation</a></p>
                </div>
              )}
            </div>

            {apiDetails.info.contact && (
              <div>
                <h3>Contact</h3>
                {apiDetails.info.contact.name && <p><strong>Name:</strong> {apiDetails.info.contact.name}</p>}
                {apiDetails.info.contact.email && <p><strong>Email:</strong> <a href={`mailto:${apiDetails.info.contact.email}`} style={{ color: 'white' }}>{apiDetails.info.contact.email}</a></p>}
                {apiDetails.info.contact.url && <p><strong>Website:</strong> <a href={apiDetails.info.contact.url} target="_blank" rel="noopener noreferrer" style={{ color: 'white' }}>{apiDetails.info.contact.url}</a></p>}
              </div>
            )}
            
            <div style={{ textAlign: 'center', marginTop: '20px' }}>
              <button 
                onClick={() => navigate('/')} 
                style={{ padding: '10px 20px', fontSize: '16px', cursor: 'pointer', backgroundColor: '#36C2F4', color: 'white', border: 'none', borderRadius: '5px' }}
              >
                Explore Web APIs
              </button>
            </div>
          </div>
        ) : (
          <p style={{ textAlign: 'center' }}>Loading...</p>
        )}
      </div>
    </div>
  );
};

export default APIDetails;
