import React, { useState } from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

interface Api {
  name: string;
  logoUrl?: string;
}

interface SidebarProps {
  providers: string[];
  onSelect: (apiName: string) => void;
  onClose: () => void;
  showProviders: boolean;
}

interface ProviderItemProps {
  isSelected: boolean;
  isExpanded: boolean;
}

const SidebarContainer = styled.div<{ showProviders: boolean }>`
  width: 350px;
  background-color: #3f607a;
  border-left: 3px solid #07a1ee;
  position: fixed;
  right: 0;
  top: 0;
  bottom: 0;
  overflow-y: auto;
  padding: 20px;
  color: white;
  z-index: 1000;
  transition: transform 0.3s ease-in-out;
  transform: ${({ showProviders }) => (showProviders ? 'translateX(0)' : 'translateX(100%)')};
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
`;

const ProviderItem = styled.div<ProviderItemProps>`
  cursor: pointer;
  margin-bottom: 15px;
  font-size: 1.2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: ${({ isSelected }) => (isSelected ? '#131924' : 'transparent')};
  color: ${({ isSelected }) => (isSelected ? '#FFFFFF' : 'inherit')};
  padding: 12px 15px;
  border-radius: 8px;
  position: relative;
  box-shadow: ${({ isSelected }) => (isSelected ? '0 4px 12px rgba(0, 0, 0, 0.3)' : 'none')};
  transition: background-color 0.3s ease, box-shadow 0.3s ease;

  &:hover {
    background-color: #131924;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  }

  &::after {
    content: '';
    display: block;
    width: 0;
    height: 0;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-top: ${({ isExpanded }) => (isExpanded ? '6px solid #FFFFFF' : 'none')};
    border-bottom: ${({ isExpanded }) => (isExpanded ? 'none' : '6px solid #FFFFFF')};
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    transition: transform 0.3s ease;
  }
`;

const ApiItem = styled.div<{ isSelected: boolean }>`
  margin-left: 20px;
  display: flex;
  align-items: center;
  cursor: pointer;
  background-color: ${({ isSelected }) => (isSelected ? '#131924' : 'transparent')};
  color: ${({ isSelected }) => (isSelected ? '#FFFFFF' : 'inherit')};
  padding: 10px 12px;
  border-radius: 6px;
  transition: background-color 0.3s ease, color 0.3s ease;

  a {
    color: ${({ isSelected }) => (isSelected ? '#FFFFFF' : 'inherit')};
    margin-left: 10px;
    text-decoration: none;
    transition: color 0.3s ease;

    &:hover {
      color: #07a1ee;
    }
  }
`;

const ApiLogo = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 5px;
  margin-right: 10px;
  object-fit: cover;
`;

const Sidebar: React.FC<SidebarProps> = ({ providers, onSelect, onClose, showProviders }) => {
  const [expandedProvider, setExpandedProvider] = useState<string | null>(null);
  const [apis, setApis] = useState<Api[]>([]);
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  const [selectedApi, setSelectedApi] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleToggleProvider = async (provider: string) => {
    if (expandedProvider === provider) {
      setExpandedProvider(null);
      setApis([]);
    } else {
      setExpandedProvider(provider);
      setSelectedProvider(provider);
      setSelectedApi(null); // Reset the selected API when a new provider is selected
      try {
        const response = await fetch(`https://api.apis.guru/v2/${provider}.json`);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const providerData = await response.json();
        const apisArray = Object.keys(providerData.apis || {}).map((key) => ({
          name: key,
          logoUrl: providerData.apis[key]?.info?.xLogo?.url || '',
        }));
        setApis(apisArray);
        setError(null);
      } catch (error) {
        console.error('Failed to fetch API details:', error);
        setError('Failed to fetch API details.');
      }
    }
  };

  const handleSelectApi = (apiName: string) => {
    setSelectedApi(apiName);
    onSelect(apiName);
  };

  const handleImageError = (event: React.SyntheticEvent<HTMLImageElement, Event>) => {
    event.currentTarget.src = 'https://via.placeholder.com/50'; // Fallback image URL
  };

  return (
    <SidebarContainer showProviders={showProviders}>
      {onClose && (
        <button
          onClick={onClose}
          style={{ background: 'white', color: 'black', border: 'none', borderRadius: '5px', padding: '5px 10px', cursor: 'pointer' }}
        >
          Close
        </button>
      )}
      <h2 style={{ textAlign: 'center' }}>Select Providers</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <ul>
        {providers.map((provider) => (
          <div key={provider}>
            <ProviderItem
              onClick={() => handleToggleProvider(provider)}
              isSelected={selectedProvider === provider}
              isExpanded={expandedProvider === provider}
            >
              {provider}
            </ProviderItem>
            {expandedProvider === provider &&
              apis.map((api, index) => (
                <ApiItem
                  key={index}
                  isSelected={selectedProvider === provider && selectedApi === api.name}
                  onClick={() => handleSelectApi(api.name)}
                >
                  <ApiLogo
                    src={api.logoUrl || 'https://via.placeholder.com/50'}
                    alt={`${api.name} logo`}
                    onError={handleImageError}
                  />
                  <Link to={`/api-details/${provider}`}>{api.name}</Link>
                </ApiItem>
              ))}
          </div>
        ))}
      </ul>
    </SidebarContainer>
  );
};

export default Sidebar;
